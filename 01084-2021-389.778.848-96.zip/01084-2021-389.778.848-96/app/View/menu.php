<nav id="menu">
    <ul>
        <li><a href="?p=pessoa">Pessoa</a></li> |
        <li><a href="?p=conta">Conta</a></li> |
        <li><a href="?p=movimentacao">Movimentação</a></li>
    </ul>
</nav>